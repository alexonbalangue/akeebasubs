<?php
defined('_JEXEC') or die();

define('AKEEBASUBS_VERSION', '1.0');
define('AKEEBASUBS_DATE', '2016-04-24');
define('AKEEBASUBS_VERSIONHASH', md5(AKEEBASUBS_VERSION.AKEEBASUBS_DATE.JFactory::getConfig()->get('secret','')));