<?php
/**
 *  @package AkeebaSubs
 *  @copyright Copyright (c)2010-2016 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 */

defined('_JEXEC') or die;
?>
<div class="alert alert-info">
	<?php echo JText::_('COM_AKEEBASUBS_APICOUPONS_INFO'); ?>
</div>

<?php echo $this->getRenderedForm(); ?>