<?php
/**
 * @package		Akeeba Subscriptions
 * @copyright	2015 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license		GNU GPL version 3 or later
 */

namespace Akeeba\Subscriptions\Admin\Model;

defined('_JEXEC') or die;

use Akeeba\Subscriptions\Site\Model\TaxHelper as FrontendTaxHelper;

class TaxHelper extends FrontendTaxHelper
{

}