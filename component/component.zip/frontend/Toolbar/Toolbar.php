<?php
/**
 * @package   AkeebaSubs
 * @copyright Copyright (c)2010-2016 Nicholas K. Dionysopoulos
 * @license   GNU General Public License version 3, or later
 */

namespace Akeeba\Subscriptions\Site\Toolbar;

defined('_JEXEC') or die;

class Toolbar extends \FOF30\Toolbar\Toolbar
{
}